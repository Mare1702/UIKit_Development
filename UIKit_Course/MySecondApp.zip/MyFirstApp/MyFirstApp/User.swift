//
//  User.swift
//  MyFirstApp
//
//  Created by MacBook 16 on 31/01/23.
//

import Foundation

struct User{
    
    let name: String
    let email: String
    let age: Int
    let phone: String
    
    init(name: String, email: String, age: Int, phone: String) {
        self.name = name
        self.email = email
        self.age = age
        self.phone = phone
    }
    
}
