//
//  ViewController.swift
//  MyFirstApp
//
//  Created by MacBook 16 on 31/01/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    //MARK: Outlets
    
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var ageDescriptionLabel: UILabel!
    @IBOutlet weak var ageSwitch: UISwitch!
    @IBOutlet weak var ageSlider: UISlider!
    @IBOutlet weak var confirmButton: UIButton!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
 
    @IBOutlet weak var ageAlertLabel: UILabel!
    @IBOutlet weak var ageValueLabel: UILabel!
    @IBOutlet weak var errorLabel: UILabel!
    

    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    //MARK: Actions
    
    @IBAction func ageSwitchChanged(_ sender: Any) {
        if ageSwitch.isOn == false {
            confirmButton.isEnabled = false
            ageSlider.isEnabled = false
        }else{
            confirmButton.isEnabled = true
            ageSlider.isEnabled = true
        }
    }
    
    @IBAction func buttonDidPressed(_ sender: Any) {
        guard let name = nameTextField.text,
              let email = emailTextField.text,
              let phone = phoneTextField.text else {return}
        
    
       /* print("NAME: \(name)")
        print("EMAIL: \(email)")
        print("PHONE: \(phone)")*/
        
        
        
        
        if name.isEmpty || email.isEmpty || phone.isEmpty{
            errorLabel.isHidden = false
        }else{
            errorLabel.isHidden = true
            let newUser = User(name: name, email: email, age: Int(ageSlider.value), phone: phone)
            print("SING UP USER \(newUser)")
            PresentHomeModule(with: newUser)
            
        }
        
        
    
        
    }
    @IBAction func sliderChanged(_ sender: Any) {
        print("VALUE: \(ageSlider.value)")
        ageValueLabel.text = "\(Int(ageSlider.value))"
        
    }
    
    
    
    func setUpUI(){
        
        
        profileImage.image = UIImage(named: "profileImage")
        
        titleLabel.text = "Registrate"
        ageDescriptionLabel.text = "Soy mayor de edad"
        ageAlertLabel.text = "Ingresa tu edad"
        
        nameTextField.placeholder = "Nombre"
        emailTextField.placeholder = "Email"
        phoneTextField.placeholder = "Telefono"
        
        
        confirmButton.setTitle("Registrate", for: .normal)
        confirmButton.isEnabled = false
        
        
        ageSwitch.isOn = false
        
        ageSlider.isEnabled = false
        
        
        ageValueLabel.text = ""
        
        
        ageSlider.minimumValue = 18
        ageSlider.maximumValue = 90
        
        
        errorLabel.text = "Faltan datos"
        errorLabel.isHidden = true
        errorLabel.textColor = .red
        
       
        
        
        
    }
    
    func PresentHomeModule(with user: User){
        //Instanciamos la vista presentar
        let homeStoryboard = UIStoryboard(name: "HomeStoryboard", bundle: .main)
        let homeViewController = homeStoryboard.instantiateViewController(withIdentifier: "HomeVC")as! HomeViewController
        //Cambiar la propiedad de la instancia
        homeViewController.user = user
        //mandar a presentar la pantalla
        self.present(homeViewController, animated: true, completion: nil)
        
        
        
    }


}

